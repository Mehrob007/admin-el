export default function ShopPage() {
  return (
    <div>ShopPage</div>
  )
}
