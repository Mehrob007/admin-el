import Router from "../router/router";
import "../components/layout/globalStyle.css";

export default function App() {
  return <Router />;
}
