import{r as t}from"./index-pjw6mKoR.js";function e(){t.useEffect(()=>{document.location.href="http://localhost:5174"},[])}export{e as default};
